use cross_river_bank
-- Task 1: Customer Risk Analysis
--   Task :Identify customers with poor credit scores who are associated with loans marked as high default risk. Your goal is to isolate potentially risky borrowers that the bank should monitor or intervene with. 
SELECT c.customer_id,c.name,c.credit_score,l.loan_id,l.default_risk
FROM customer_table c
JOIN loan_table l ON c.customer_id = l.customer_id
WHERE c.credit_score < 600 AND l.default_risk = 'High'
ORDER BY c.credit_score ASC;

-- Task 2: Loan Purpose Insights
-- Task: Analyze the types of loan purposes customers borrow for (e.g., home, education, business) and determine which categories are most popular and profitable.
SELECT loan_purpose,COUNT(*) AS total_loans,SUM(loan_amount) AS total_amount,
ROUND(SUM(loan_amount) * 100.0 / SUM(SUM(loan_amount)) OVER (), 2) AS percentage_contribution
FROM loan_table
GROUP BY loan_purpose
ORDER BY total_amount DESC;

-- Task 3: High-Value Transactions
-- Task: Detect transactions that exceed 30% of their related loan amount. These anomalies could suggest unusual activities worth investigating.
SELECT t.transaction_id,t.loan_id,t.transaction_amount,l.loan_amount,
    ROUND(t.transaction_amount / l.loan_amount, 2) AS percentage
FROM transaction_table t
JOIN loan_table l ON t.loan_id = l.loan_id
WHERE t.transaction_amount > 0.3 * l.loan_amount;

-- Task 4: Missed EMI Count 
-- Task: Calculate the number of missed EMI payments for each loan and list those with high missed counts. 
SELECT loan_id,COUNT(*) AS missed_emi_count
FROM transaction_table
WHERE transaction_type = 'Missed EMI'
GROUP BY loan_id
HAVING missed_emi_count > 1;

-- Task 5: Regional Loan Distribution 
-- Task: Evaluate how loan disbursement is spread across different geographic areas based on customer addresses.
SELECT c.address,COUNT(l.loan_id) AS loan_count,SUM(l.loan_amount) AS total_loan_amount
FROM customer_table c
JOIN loan_table l ON c.customer_id = l.customer_id
GROUP BY c.address
ORDER BY total_loan_amount DESC;

-- Task 6: Loyal Customers 
-- Task: List all customers who have been associated with the bank for over five years, and analyze their borrowing patterns and loan behavior. 
SELECT c.customer_id,c.name,c.customer_since,COUNT(l.loan_id) AS total_loans
FROM customer_table c
LEFT JOIN loan_table l ON c.customer_id = l.customer_id
WHERE c.customer_since <= DATE_SUB(CURDATE(), INTERVAL 5 YEAR)
GROUP BY c.customer_id;

-- Task 7: High-Performing Loans 
-- Task: Identify loans that have consistently been paid on time and reflect excellent repayment history. 
SELECT loan_id,COUNT(*) AS successful_emis
FROM transaction_table
WHERE transaction_type = 'EMI Payment'
GROUP BY loan_id
ORDER BY successful_emis DESC;

-- Task 8: Age-Based Loan Analysis 
-- Task: Analyze how borrowing behavior and loan sizes differ across customer age groups.
SELECT 
    CASE 
        WHEN age < 25 THEN 'Under 25'
        WHEN age BETWEEN 25 AND 35 THEN '25-35'
        WHEN age BETWEEN 36 AND 50 THEN '36-50'
        ELSE 'Above 50'
    END AS age_group,
    COUNT(l.loan_id) AS loan_count,
    AVG(l.loan_amount) AS avg_loan_amount
FROM customer_table c
JOIN loan_table l ON c.customer_id = l.customer_id
GROUP BY age_group;

-- Task 9: Seasonal Transaction Trends 
-- Task: Explore how loan-related transactions vary by month and year to identify seasonal repayment or borrowing trends.
SELECT YEAR(STR_TO_DATE(transaction_date, '%c/%e/%Y %H:%i')) AS year,MONTH(STR_TO_DATE(transaction_date, '%c/%e/%Y %H:%i')) AS month,
COUNT(*) AS transaction_count,SUM(transaction_amount) AS total_amount
FROM transaction_table
GROUP BY year, month
ORDER BY year, month;

-- Task 10: Repayment History Analysis 
-- Task: Rank loans based on how consistently they’ve been repaid, using advanced SQL functions like ranking and aggregation.
SELECT loan_id,COUNT(*) AS total_paid,RANK() OVER (ORDER BY COUNT(*) DESC) AS repayment_rank
FROM transaction_table
WHERE transaction_type = 'EMI Payment'
GROUP BY loan_id;

-- Task 11: Credit Score vs. Loan Amount 
-- Task: Compare average loan amounts disbursed to customers across different credit score ranges to identify patterns. 
SELECT 
    CASE 
        WHEN credit_score < 600 THEN 'Poor (<600)'
        WHEN credit_score BETWEEN 600 AND 700 THEN 'Average (600-700)'
        WHEN credit_score > 700 THEN 'Good (>700)'
    END AS credit_range,
    AVG(l.loan_amount) AS avg_loan_amount
FROM customer_table c
JOIN loan_table l ON c.customer_id = l.customer_id
GROUP BY credit_range;

-- Task 12: Top Borrowing Regions 
-- Task: Identify geographic regions with the highest loan disbursements, both in volume and amount.
SELECT c.address,COUNT(l.loan_id) AS loan_count,SUM(l.loan_amount) AS total_disbursed
FROM customer_table c
JOIN loan_table l ON c.customer_id = l.customer_id
GROUP BY c.address
ORDER BY total_disbursed DESC
LIMIT 10;

-- Task 13: Early Repayment Patterns 
-- Task: Identify loans that are being repaid earlier than their expected duration and assess their impact on interest revenue. 
SELECT loan_id,MIN(STR_TO_DATE(transaction_date, '%c/%e/%Y %H:%i')) AS first_payment,
MAX(STR_TO_DATE(transaction_date, '%c/%e/%Y %H:%i')) AS last_payment,COUNT(*) AS payment_count
FROM transaction_table
WHERE transaction_type = 'EMI Payment'
GROUP BY loan_id
HAVING DATEDIFF(MAX(STR_TO_DATE(transaction_date, '%c/%e/%Y %H:%i')), 
MIN(STR_TO_DATE(transaction_date, '%c/%e/%Y %H:%i'))) < 365; -- Assuming 1 year loan







